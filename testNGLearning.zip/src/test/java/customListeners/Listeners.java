package customListeners;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.Reporter;

public class Listeners implements ITestListener{

	public void onTestStart(ITestResult result) {
		// TODO Auto-generated method stub
		
	}

	public void onTestSuccess(ITestResult result) {
		// TODO Auto-generated method stub
		System.out.println("Passed test Name : " +result.getName());
		
	}

	public void onTestFailure(ITestResult result) {
		// TODO Auto-generated method stub
		System.setProperty("org.uncommons.reportng.escape-output", "false");
		Reporter.log("<table style=\"width:100%\" border=\"1\">\r\n" + 
				"  <tr>\r\n" + 
				"    <th>Negative Case number</th>\r\n" + 
				"    <th>Expected</th> \r\n" + 
				"    <th>Actual</th>\r\n" + 
				"    <th>Status</th>\r\n" + 
				"  </tr>\r\n" + 
				"  <tr>\r\n" + 
				"    <td>Negative Case 1 : Signup1</td>\r\n" + 
				"    <td>EMAIL-ID should have proper nomenclature with a specific domain name</td> \r\n" + 
				"    <td>EMAIL-ID is not having required format</td>\r\n" + 
				"    <td>Fail</td>\r\n" + 
				"  </tr>\r\n" + 
				"  <tr>\r\n" + 
				"    <td>Negative Case 2 : Signup2</td>\r\n" + 
				"    <td>Password should Match</td> \r\n" + 
				"    <td>Password did not matched</td>\r\n" + 
				"    <td>Fail</td>\r\n" + 
				"  </tr>\r\n" + 
				" <tr>\r\n" + 
				"    <td>Negative Case 3 : Login1</td>\r\n" + 
				"    <td>The password should match with configured mail-id/user-name</td> \r\n" + 
				"    <td>The configured Mail-id/User name does not matched with password entered</td>\r\n" + 
				"    <td>Fail</td>\r\n" + 
				"  </tr>\r\n" + 
				"</table>");
		System.out.println("Failed test name : " +result.getName());
		
	}

	public void onTestSkipped(ITestResult result) {
		// TODO Auto-generated method stub
		
	}

	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		// TODO Auto-generated method stub
		
	}

	public void onStart(ITestContext context) {
		// TODO Auto-generated method stub
		
	}

	public void onFinish(ITestContext context) {
		// TODO Auto-generated method stub
		
	}

}
