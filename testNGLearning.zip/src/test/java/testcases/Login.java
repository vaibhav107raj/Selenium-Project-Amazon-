package testcases;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Login {
	public static WebDriver driver;
	
	@BeforeTest
	public void doInitial()  {
		//WebDriverManager.chromedriver().setup();
		//driver = new ChromeDriver();
        driver.get("https://www.amazon.com/");
        //driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
	}
	
	@Test(priority=1)
	public void doLogin1() throws InvalidFormatException, IOException {
		driver.findElement(By.xpath("//*[@id=\"nav-link-accountList\"]/span[1]")).click();
		File f = new File("C:\\Users\\vaibh\\eclipse-workspace\\testNGLearning\\src\\test\\resources\\excel\\testdata.xlsx");
        FileInputStream fi = new FileInputStream(f);
        
        
        Workbook workbook = WorkbookFactory.create(fi);
        
        
        Sheet sheet1 = workbook.getSheetAt(1);
        Row l1row1 = sheet1.getRow(1);
        
        Cell r1login1 = l1row1.getCell(0);
        
        Cell r1login2 = l1row1.getCell(1);
       
        String r1l1 = r1login1.toString();
        String r1l2 = r1login2.toString();
        
        
        //driver.get("https://www.amazon.com/ap/signin?_encoding=UTF8&ignoreAuthState=1&openid.assoc_handle=usflex&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.mode=checkid_setup&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&openid.ns.pape=http%3A%2F%2Fspecs.openid.net%2Fextensions%2Fpape%2F1.0&openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.com%2F%3Fref_%3Dnav_signin&switch_account=");
        //driver.findElement(By.id("ap_email")).sendKeys("trial1@gmail.com");
        driver.findElement(By.id("ap_email")).sendKeys(r1l1);
        //sendkeys is used to type your input
        
        driver.findElement(By.id("ap_password")).sendKeys(r1l2);
        
        driver.findElement(By.id("signInSubmit")).click();
        String fileName = "Login_Negative"+".jpg";

		File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(screenshot, new File(".//Screenshot//LoginNegativeScreenshot//"+fileName));
	
        
        
        driver.findElement(By.xpath("//*[@id=\"a-page\"]/div[1]/div[1]/div/a/i")).click();
        
        
	}
	
	@Test(priority=2)
	public void doLogin2() throws InvalidFormatException, IOException {
		File f = new File("C:\\Users\\vaibh\\eclipse-workspace\\testNGLearning\\src\\test\\resources\\excel\\testdata.xlsx");
        FileInputStream fi = new FileInputStream(f);
        
        
        Workbook workbook = WorkbookFactory.create(fi);
        
        driver.findElement(By.xpath("//*[@id=\"nav-link-accountList\"]/span[1]")).click();
        Sheet sheet1 = workbook.getSheetAt(1);
        Row l2row2 = sheet1.getRow(2);
        
        Cell r2login1 = l2row2.getCell(0);
        
        Cell r2login2 = l2row2.getCell(1);
       
        String r2l1 = r2login1.toString();
        String r2l2 = r2login2.toString();
        //driver.get("https://www.amazon.com/ap/signin?_encoding=UTF8&ignoreAuthState=1&openid.assoc_handle=usflex&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.mode=checkid_setup&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&openid.ns.pape=http%3A%2F%2Fspecs.openid.net%2Fextensions%2Fpape%2F1.0&openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.com%2F%3Fref_%3Dnav_signin&switch_account=");
        driver.findElement(By.id("ap_email")).sendKeys(r2l1);
       
        driver.findElement(By.id("ap_password")).sendKeys(r2l2);
        
        driver.findElement(By.id("signInSubmit")).click();
        
        String fileName = "Login_Positive"+".jpg";

		File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(screenshot, new File(".//Screenshot//LoginPositiveScreenshot//"+fileName));
        
        
        
	}
}
