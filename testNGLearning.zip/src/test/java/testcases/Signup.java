package testcases;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Signup {
	
	public static WebDriver driver;
	
	@BeforeTest
	public void doInitial()  {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
        driver.get("https://www.amazon.com/");
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
	}

	@Test(priority=1)
	public void doSignup1() throws IOException, InvalidFormatException {
		
		
		
		
		File f = new File("C:\\Users\\vaibh\\eclipse-workspace\\testNGLearning\\src\\test\\resources\\excel\\testdata.xlsx");
        FileInputStream fi = new FileInputStream(f);
        Workbook workbook = WorkbookFactory.create(fi);
		Sheet sheet0 = workbook.getSheetAt(0);
        Row row1 = sheet0.getRow(1);
        
        Cell signup1 = row1.getCell(0);
        
        Cell signup2 = row1.getCell(1);
        Cell signup3 = row1.getCell(2);
        Cell signup4 = row1.getCell(3);
        String r1s1 = signup1.toString();
        String r1s2 = signup2.toString();
        String r1s3 = signup3.toString();
        String r1s4 = signup4.toString();
        SoftAssert sa1 = new SoftAssert();
		driver.findElement(By.xpath("//*[@id=\"nav-link-accountList\"]/span[1]")).click();
        driver.findElement(By.id("createAccountSubmit")).click();
        driver.findElement(By.id("ap_customer_name")).sendKeys(r1s1);
        driver.findElement(By.id("ap_email")).sendKeys(r1s2);
        sa1.assertEquals("ACTUAL: EMAIL-ID is not having required format", "EXPECTED : EMAIL-ID should have proper nomenclature with a specific domain name ", "This is a negative case as ");
        //sa1.assertEquals(true, false, "email id should have proper format");
        driver.findElement(By.id("ap_password")).sendKeys(r1s3);
        driver.findElement(By.id("ap_password_check")).sendKeys(r1s4);
        
        driver.findElement(By.id("continue")).click();
        String fileName = "Signup1_Negative"+".jpg";

		File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(screenshot, new File(".//Screenshot//SignupNegativeScreenshot//"+fileName));
        driver.findElement(By.xpath("//*[@id=\"a-page\"]/div[1]/div[1]/div/a/i")).click();
        sa1.assertAll();
        
        
        
        
	}
	
	@Test(priority=2)
	public void doSignup2() throws IOException, InvalidFormatException {
		
		
		
		
		File f = new File("C:\\Users\\vaibh\\eclipse-workspace\\testNGLearning\\src\\test\\resources\\excel\\testdata.xlsx");
        FileInputStream fi = new FileInputStream(f);
        
        
        Workbook workbook = WorkbookFactory.create(fi);
		Sheet sheet0 = workbook.getSheetAt(0);
		Row row2 = sheet0.getRow(2);
        
        Cell r2signup1 = row2.getCell(0);
        
        Cell r2signup2 = row2.getCell(1);
        Cell r2signup3 = row2.getCell(2);
        Cell r2signup4 = row2.getCell(3);
        String r2s1 = r2signup1.toString();
        String r2s2 = r2signup2.toString();
        String r2s3 = r2signup3.toString();
        String r2s4 = r2signup4.toString();
        
        SoftAssert sa = new SoftAssert();
        driver.findElement(By.xpath("//*[@id=\"nav-link-accountList\"]/span[1]")).click();
        driver.findElement(By.id("createAccountSubmit")).click();
        driver.findElement(By.id("ap_customer_name")).sendKeys(r2s1);
        driver.findElement(By.id("ap_email")).sendKeys(r2s2);
        driver.findElement(By.id("ap_password")).sendKeys(r2s3);
        driver.findElement(By.id("ap_password_check")).sendKeys(r2s4);
        sa.assertEquals("ACTUAL: Password did not matched", "EXPECTED: Password should Match", "This is negative case as ");
        //sa.assertEquals(true, false, "Password and Confirm Password should match");
        driver.findElement(By.id("continue")).click();
        String fileName = "Signup2_Negative"+".jpg";

		File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(screenshot, new File(".//Screenshot//SignupNegativeScreenshot//"+fileName));
        driver.findElement(By.xpath("//*[@id=\"a-page\"]/div[1]/div[1]/div/a/i")).click();
      
        sa.assertAll();
        
        
        
	}
	
	@Test(priority=3)
	public void doSignup3() throws IOException, InvalidFormatException {
		
		
		
		
		File f = new File("C:\\Users\\vaibh\\eclipse-workspace\\testNGLearning\\src\\test\\resources\\excel\\testdata.xlsx");
        FileInputStream fi = new FileInputStream(f);
        
        
        Workbook workbook = WorkbookFactory.create(fi);
		Sheet sheet0 = workbook.getSheetAt(0);
		Row row3 = sheet0.getRow(3);
        
        Cell r3signup1 = row3.getCell(0);
        
        Cell r3signup2 = row3.getCell(1);
        Cell r3signup3 = row3.getCell(2);
        Cell r3signup4 = row3.getCell(3);
        String r3s1 = r3signup1.toString();
        String r3s2 = r3signup2.toString();
        String r3s3 = r3signup3.toString();
        String r3s4 = r3signup4.toString();
        
        driver.findElement(By.xpath("//*[@id=\"nav-link-accountList\"]/span[1]")).click();
        driver.findElement(By.id("createAccountSubmit")).click();
        driver.findElement(By.id("ap_customer_name")).sendKeys(r3s1);
        driver.findElement(By.id("ap_email")).sendKeys(r3s2);
        driver.findElement(By.id("ap_password")).sendKeys(r3s3);
        driver.findElement(By.id("ap_password_check")).sendKeys(r3s4);
        driver.findElement(By.id("continue")).click();
        String fileName = "Signup3_Positive"+".jpg";

		File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(screenshot, new File(".//Screenshot//SignupPositiveScreenshot//"+fileName));
        driver.findElement(By.xpath("//*[@id=\"a-page\"]/div[1]/div/a/i")).click();
      
      
        
	}
	
	@Test(priority=4)
	public void doLogin1() throws InvalidFormatException, IOException {
		driver.findElement(By.xpath("//*[@id=\"nav-link-accountList\"]/span[1]")).click();
		File f = new File("C:\\Users\\vaibh\\eclipse-workspace\\testNGLearning\\src\\test\\resources\\excel\\testdata.xlsx");
        FileInputStream fi = new FileInputStream(f);
        
        
        Workbook workbook = WorkbookFactory.create(fi);
        
        
        Sheet sheet1 = workbook.getSheetAt(1);
        Row l1row1 = sheet1.getRow(1);
        
        Cell r1login1 = l1row1.getCell(0);
        
        Cell r1login2 = l1row1.getCell(1);
       
        String r1l1 = r1login1.toString();
        String r1l2 = r1login2.toString();
        
        SoftAssert sa2 = new SoftAssert();
        //driver.get("https://www.amazon.com/ap/signin?_encoding=UTF8&ignoreAuthState=1&openid.assoc_handle=usflex&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.mode=checkid_setup&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&openid.ns.pape=http%3A%2F%2Fspecs.openid.net%2Fextensions%2Fpape%2F1.0&openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.com%2F%3Fref_%3Dnav_signin&switch_account=");
        //driver.findElement(By.id("ap_email")).sendKeys("trial1@gmail.com");
        driver.findElement(By.id("ap_email")).sendKeys(r1l1);
        //sendkeys is used to type your input
        
        driver.findElement(By.id("ap_password")).sendKeys(r1l2);
        sa2.assertEquals("ACTUAL : The configured Mail-id/User name does not matched with password entered", "EXPECTED : The password should match with configured mail-id/user-name", "This is a negative case as ");
        //sa2.assertEquals(true, false, "Valid Password should be entered");
        driver.findElement(By.id("signInSubmit")).click();
        String fileName = "Login_Negative"+".jpg";

		File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(screenshot, new File(".//Screenshot//LoginNegativeScreenshot//"+fileName));
	
        
        
        driver.findElement(By.xpath("//*[@id=\"a-page\"]/div[1]/div[1]/div/a/i")).click();
        sa2.assertAll();
        
	}
	
	@Test(priority=5)
	public void doLogin2() throws InvalidFormatException, IOException {
		File f = new File("C:\\Users\\vaibh\\eclipse-workspace\\testNGLearning\\src\\test\\resources\\excel\\testdata.xlsx");
        FileInputStream fi = new FileInputStream(f);
        
        
        Workbook workbook = WorkbookFactory.create(fi);
        
        driver.findElement(By.xpath("//*[@id=\"nav-link-accountList\"]/span[1]")).click();
        Sheet sheet1 = workbook.getSheetAt(1);
        Row l2row2 = sheet1.getRow(2);
        
        Cell r2login1 = l2row2.getCell(0);
        
        Cell r2login2 = l2row2.getCell(1);
       
        String r2l1 = r2login1.toString();
        String r2l2 = r2login2.toString();
        //driver.get("https://www.amazon.com/ap/signin?_encoding=UTF8&ignoreAuthState=1&openid.assoc_handle=usflex&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.mode=checkid_setup&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&openid.ns.pape=http%3A%2F%2Fspecs.openid.net%2Fextensions%2Fpape%2F1.0&openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.com%2F%3Fref_%3Dnav_signin&switch_account=");
        driver.findElement(By.id("ap_email")).sendKeys(r2l1);
       
        driver.findElement(By.id("ap_password")).sendKeys(r2l2);
        
        driver.findElement(By.id("signInSubmit")).click();
        
        String fileName = "Login_Positive"+".jpg";

		File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(screenshot, new File(".//Screenshot//LoginPositiveScreenshot//"+fileName));
        
        
        
	}
	@Test(priority=6)
	public void doCart() throws IOException, InvalidFormatException {
		
//		File f = new File("C:\\Users\\vaibh\\eclipse-workspace\\testNGLearning\\src\\test\\resources\\excel\\testdata.xlsx");
//        FileInputStream fi = new FileInputStream(f);
//        
//        
//        Workbook workbook = WorkbookFactory.create(fi);
//        
//        
//        Sheet sheet2 = workbook.getSheetAt(2);
//        Row c1row1 = sheet2.getRow(1);
//        
//        Cell r1cart = c1row1.getCell(0);
//        
//        
//       
//        String r1c1 = r1cart.toString();
		
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys("Happiness Is a Choice: New Ways to Enhance Joy and Meaning in Your Life");
        
        driver.findElement(By.xpath("//*[@id=\"nav-search\"]/form/div[2]/div/input")).click();
        
        driver.findElement(By.xpath("//*[@id=\"search\"]/div[1]/div[2]/div/span[3]/div[1]/div[1]/div/div/div/div[2]/div[2]/div/div[1]/div/div/div[1]/h2/a/span")).click();
        
        driver.findElement(By.xpath("//*[@id=\"add-to-cart-button\"]")).click();
        
        driver.findElement(By.xpath("//*[@id=\"nav-cart\"]/span[3]")).click();
        
        String fileName = "Cart"+".jpg";

		File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(screenshot, new File(".//Screenshot//CartScreenshot//"+fileName));
        
		driver.findElement(By.xpath("//*[@id=\"sc-buy-box-ptc-button\"]/span/input")).click();
		String fileName1 = "checkout"+".jpg";

		File screenshot1 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(screenshot1, new File(".//Screenshot//ChekoutScreenshot//"+fileName1));
        
        //driver.close();
        driver.quit();
	}
}
