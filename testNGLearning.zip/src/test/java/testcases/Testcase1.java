package testcases;

import org.testng.annotations.Test;

public class Testcase1 {
	
	
	@Test(priority=1)
	public void doLogin() {
		System.out.println("First");
	}
	
	
	@Test(priority=2)
	public void doForward() {
		System.out.println("Second");
	}
	

}
