package testcases;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Testcase2 {

	@Test
	public void doTest() {
		String acctual = "Vaibhav";
		String expected = "Raj";
		Assert.assertEquals(acctual, expected);
	}
}
