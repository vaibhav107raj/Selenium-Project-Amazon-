package testcases;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

public class Cart {
	public static WebDriver driver;
	
	@Test
	public void doCart() throws IOException, InvalidFormatException {
		
		
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys("Happiness Is a Choice: New Ways to Enhance Joy and Meaning in Your Life");
        
        driver.findElement(By.xpath("//*[@id=\"nav-search\"]/form/div[2]/div/input")).click();
        
        driver.findElement(By.xpath("//*[@id=\"search\"]/div[1]/div[2]/div/span[3]/div[1]/div[1]/div/div/div/div[2]/div[2]/div/div[1]/div/div/div[1]/h2/a/span")).click();
        
        driver.findElement(By.xpath("//*[@id=\"add-to-cart-button\"]")).click();
        
        driver.findElement(By.xpath("//*[@id=\"nav-cart\"]/span[3]")).click();
        
        String fileName = "Cart"+".jpg";

		File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(screenshot, new File(".//Screenshot//CartScreenshot//"+fileName));
      
      
        
        //driver.close();
        driver.quit();
	}

}
